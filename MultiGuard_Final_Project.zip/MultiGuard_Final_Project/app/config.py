from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
UPLOADS_DIR = DATA_DIR / 'uploads'
ORIGINALS_DIR = UPLOADS_DIR / 'originals'
PROTECTED_DIR = UPLOADS_DIR / 'protected'
KEYS_DIR = DATA_DIR / 'keys'
STATIC_DIR = BASE_DIR / 'app' / 'static'
TEMPLATES_DIR = BASE_DIR / 'app' / 'templates'
DB_PATH = DATA_DIR / 'multiguard.db'
DATABASE_URL = f"sqlite:///{DB_PATH}"
SECRET_KEY = os.getenv('MULTIGUARD_SECRET', 'dev-secret-change-me')
ALLOWED_EXTENSIONS = {'.txt', '.pdf', '.docx'}
RSA_KEY_SIZE = 2048
APP_NAME = 'MultiGuard'

for p in [DATA_DIR, UPLOADS_DIR, ORIGINALS_DIR, PROTECTED_DIR, KEYS_DIR, STATIC_DIR, TEMPLATES_DIR]:
    p.mkdir(parents=True, exist_ok=True)
