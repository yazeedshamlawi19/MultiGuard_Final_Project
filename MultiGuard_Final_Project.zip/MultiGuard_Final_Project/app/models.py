from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    organization = Column(String(255), nullable=True)
    role = Column(String(50), default='user', nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    documents = relationship('DocumentRecord', back_populates='user')

class DocumentRecord(Base):
    __tablename__ = 'documents'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    document_id = Column(String(64), unique=True, nullable=False, index=True)
    original_filename = Column(String(255), nullable=False)
    original_path = Column(String(500), nullable=False)
    protected_path = Column(String(500), nullable=False)
    file_type = Column(String(16), nullable=False)
    mode = Column(String(32), nullable=False, default='embedded')
    owner = Column(String(255), nullable=False)
    organization = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    content_hash = Column(String(64), nullable=False)
    normalized_text_preview = Column(Text, nullable=True)
    signed_payload_json = Column(Text, nullable=False)
    signature_b64 = Column(Text, nullable=False)
    watermark_present = Column(Boolean, default=True, nullable=False)
    issued_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    user = relationship('User', back_populates='documents')
    verification_logs = relationship('VerificationLog', back_populates='document', cascade='all, delete-orphan')

class VerificationLog(Base):
    __tablename__ = 'verification_logs'
    id = Column(Integer, primary_key=True)
    document_id = Column(String(64), ForeignKey('documents.document_id'), nullable=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    submitted_filename = Column(String(255), nullable=False)
    result = Column(String(64), nullable=False)
    tamper_type = Column(String(64), nullable=False)
    severity = Column(String(32), nullable=False)
    details = Column(Text, nullable=False)
    verified_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    document = relationship('DocumentRecord', back_populates='verification_logs')
