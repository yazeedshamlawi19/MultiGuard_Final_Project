import base64
import hashlib
import json
import re
import unicodedata
from pathlib import Path
from typing import Dict
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat
from ..config import KEYS_DIR, RSA_KEY_SIZE

PRIVATE_KEY_PATH = KEYS_DIR / 'private_key.pem'
PUBLIC_KEY_PATH = KEYS_DIR / 'public_key.pem'
WATERMARK_NS = 'https://multiguard.example/ns/1.0/'


def ensure_keys() -> None:
    if PRIVATE_KEY_PATH.exists() and PUBLIC_KEY_PATH.exists():
        return
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=RSA_KEY_SIZE)
    public_key = private_key.public_key()
    PRIVATE_KEY_PATH.write_bytes(private_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    PUBLIC_KEY_PATH.write_bytes(public_key.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo))


def load_private_key():
    ensure_keys()
    return serialization.load_pem_private_key(PRIVATE_KEY_PATH.read_bytes(), password=None)


def load_public_key():
    ensure_keys()
    return serialization.load_pem_public_key(PUBLIC_KEY_PATH.read_bytes())


def normalize_text(text: str) -> str:
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    text = unicodedata.normalize('NFC', text)
    text = '\n'.join(line.rstrip() for line in text.split('\n'))
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def sha256_text(text: str) -> str:
    return hashlib.sha256(normalize_text(text).encode('utf-8')).hexdigest()


def canonicalize_payload(payload: Dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def sign_payload(payload: Dict) -> str:
    signature = load_private_key().sign(canonicalize_payload(payload), padding.PKCS1v15(), hashes.SHA256())
    return base64.b64encode(signature).decode('ascii')


def verify_signature(payload: Dict, signature_b64: str) -> bool:
    try:
        load_public_key().verify(base64.b64decode(signature_b64), canonicalize_payload(payload), padding.PKCS1v15(), hashes.SHA256())
        return True
    except (InvalidSignature, ValueError):
        return False
