import base64
import json
import re
from typing import Dict, Tuple

START_MARKER = '--- MULTIGUARD WATERMARK START ---'
END_MARKER = '--- MULTIGUARD WATERMARK END ---'


def embed_text_watermark(original_text: str, payload: Dict, signature_b64: str) -> str:
    package = {'payload': payload, 'signature_b64': signature_b64}
    encoded = base64.b64encode(json.dumps(package, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).decode('ascii')
    footer = f"\n\n{START_MARKER}\n{encoded}\n{END_MARKER}\n"
    return original_text.rstrip() + footer


def extract_text_watermark(text: str) -> Tuple[str, Dict | None, str | None]:
    pattern = re.compile(rf"\n?{re.escape(START_MARKER)}\n(?P<data>.+?)\n{re.escape(END_MARKER)}\s*$", re.DOTALL)
    match = pattern.search(text)
    if not match:
        return text, None, None
    package = json.loads(base64.b64decode(match.group('data').strip()).decode('utf-8'))
    content = text[:match.start()].rstrip()
    return content, package.get('payload'), package.get('signature_b64')
