from __future__ import annotations
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from fastapi import UploadFile
from sqlalchemy.orm import Session
from ..config import ORIGINALS_DIR, PROTECTED_DIR
from ..models import DocumentRecord, VerificationLog
from .crypto_service import normalize_text, sha256_text, sign_payload, verify_signature
from .pdf_ops import embed_pdf_watermark, extract_pdf_text, extract_pdf_watermark
from .text_ops import embed_text_watermark, extract_text_watermark
from .docx_ops import extract_docx_text, embed_docx_watermark, extract_docx_watermark

@dataclass
class VerificationResult:
    result: str
    tamper_type: str
    severity: str
    details: str
    document_id: Optional[str]
    owner: Optional[str]
    mode: Optional[str]
    content_hash_db: Optional[str]
    content_hash_embedded: Optional[str]
    content_hash_submitted: Optional[str]
    signature_valid: bool


def make_document_id() -> str:
    return f"MG-{datetime.now().strftime('%Y%m%d')}-{secrets.token_hex(4).upper()}"


def _save_upload(upload: UploadFile, base_dir: Path) -> Path:
    suffix = Path(upload.filename).suffix.lower()
    path = base_dir / f"{secrets.token_hex(12)}{suffix}"
    path.write_bytes(upload.file.read())
    upload.file.seek(0)
    return path


def _extract_text(path: Path, file_type: str) -> str:
    if file_type == 'txt':
        return path.read_text(encoding='utf-8', errors='ignore')
    if file_type == 'pdf':
        return extract_pdf_text(path)
    if file_type == 'docx':
        return extract_docx_text(path)
    raise ValueError('Unsupported file type')


def _extract_embedded(path: Path, file_type: str):
    if file_type == 'txt':
        content, payload, sig = extract_text_watermark(path.read_text(encoding='utf-8', errors='ignore'))
        return content, payload, sig
    if file_type == 'pdf':
        return _extract_text(path, 'pdf'), *extract_pdf_watermark(path)
    if file_type == 'docx':
        return _extract_text(path, 'docx'), *extract_docx_watermark(path)
    return None, None, None


def watermark_document(db: Session, upload: UploadFile, user_id: int, owner: str, organization: str, description: str, mode: str) -> DocumentRecord:
    file_type = Path(upload.filename).suffix.lower().lstrip('.')
    original_path = _save_upload(upload, ORIGINALS_DIR)
    extracted = _extract_text(original_path, file_type)
    normalized = normalize_text(extracted)
    content_hash = sha256_text(extracted)
    issued_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    payload = {
        'document_id': make_document_id(),
        'owner': owner,
        'organization': organization,
        'description': description,
        'file_type': file_type,
        'mode': mode,
        'content_hash': content_hash,
        'issued_at': issued_at,
        'version': '2.0.0'
    }
    signature_b64 = sign_payload(payload)
    protected_path = PROTECTED_DIR / f"{original_path.stem}_protected{original_path.suffix}"
    watermark_present = mode == 'embedded'
    if mode == 'embedded':
        if file_type == 'txt':
            protected_text = embed_text_watermark(extracted, payload, signature_b64)
            protected_path.write_text(protected_text, encoding='utf-8')
        elif file_type == 'pdf':
            embed_pdf_watermark(original_path, protected_path, payload, signature_b64)
        elif file_type == 'docx':
            embed_docx_watermark(original_path, protected_path, payload, signature_b64)
    else:
        protected_path.write_bytes(original_path.read_bytes())

    record = DocumentRecord(
        user_id=user_id,
        document_id=payload['document_id'],
        original_filename=upload.filename,
        original_path=str(original_path),
        protected_path=str(protected_path),
        file_type=file_type,
        mode=mode,
        owner=owner,
        organization=organization,
        description=description,
        content_hash=content_hash,
        normalized_text_preview=normalized[:2000],
        signed_payload_json=json.dumps(payload, ensure_ascii=False),
        signature_b64=signature_b64,
        watermark_present=watermark_present,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def verify_document(db: Session, upload: UploadFile, user_id: int | None = None, provided_document_id: str | None = None) -> VerificationResult:
    file_type = Path(upload.filename).suffix.lower().lstrip('.')
    submitted_path = _save_upload(upload, ORIGINALS_DIR)
    content, embedded_payload, embedded_sig = _extract_embedded(submitted_path, file_type)
    submitted_hash = sha256_text(content or '')
    record = None
    doc_id = provided_document_id or (embedded_payload or {}).get('document_id')

    if doc_id:
        record = db.query(DocumentRecord).filter_by(document_id=doc_id).one_or_none()

    if record is None:
        same_hash = db.query(DocumentRecord).filter_by(content_hash=submitted_hash).first()

        if same_hash and doc_id and same_hash.document_id != doc_id:
            result = VerificationResult(
                'TAMPERED',
                'replay_suspected',
                'high',
                'Content matches a trusted record but document identifier points elsewhere.',
                doc_id,
                None,
                None,
                same_hash.content_hash,
                (embedded_payload or {}).get('content_hash'),
                submitted_hash,
                False
            )
        elif same_hash:
            result = VerificationResult(
                'AUTHENTIC',
                'registry_match',
                'low',
                'No embedded watermark found, but content matches a trusted zero-watermark registry record.',
                same_hash.document_id,
                same_hash.owner,
                same_hash.mode,
                same_hash.content_hash,
                (embedded_payload or {}).get('content_hash'),
                submitted_hash,
                True
            )
        else:
            result = VerificationResult(
                'UNREGISTERED',
                'unregistered',
                'medium',
                'Document does not match any trusted registry record.',
                doc_id,
                None,
                None,
                None,
                (embedded_payload or {}).get('content_hash'),
                submitted_hash,
                False
            )

        db.add(
            VerificationLog(
                document_id=result.document_id,
                user_id=user_id,
                submitted_filename=upload.filename,
                result=result.result,
                tamper_type=result.tamper_type,
                severity=result.severity,
                details=result.details,
            )
        )
        db.commit()
        return result

    trusted_payload = json.loads(record.signed_payload_json)
    embedded_hash = (embedded_payload or {}).get('content_hash') if embedded_payload else None
    embedded_doc_id = (embedded_payload or {}).get('document_id') if embedded_payload else None

    watermark_readable = embedded_payload is not None
    signature_present = bool(embedded_payload and embedded_sig)
    signature_valid = verify_signature(embedded_payload, embedded_sig) if signature_present else False

    # مقارنة الـ payload المضمنة مع الـ payload الأصلية المخزنة
    payload_matches_trusted = embedded_payload == trusted_payload if embedded_payload else False

    if record.mode == 'registry_only' and submitted_hash == record.content_hash:
        result = VerificationResult(
            'AUTHENTIC',
            'registry_match',
            'low',
            'Registry-only mode verified successfully using database-backed trust.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            True
        )

    elif embedded_payload is None and record.mode == 'embedded':
        result = VerificationResult(
            'TAMPERED',
            'metadata_removed',
            'high',
            'Embedded watermark was expected but not found.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            None,
            submitted_hash,
            False
        )

    elif embedded_doc_id and embedded_doc_id != record.document_id:
        result = VerificationResult(
            'METADATA_ALTERED',
            'document_id_mismatch',
            'high',
            'Embedded document identifier does not match the trusted registry record.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            signature_valid
        )

    elif submitted_hash != record.content_hash:
        result = VerificationResult(
            'TAMPERED',
            'content_modification',
            'critical',
            'Submitted content hash differs from the original trusted hash.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            signature_valid
        )

    elif embedded_hash != record.content_hash:
        result = VerificationResult(
            'METADATA_ALTERED',
            'metadata_hash_mismatch',
            'high',
            'Embedded hash differs from the trusted database record.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            signature_valid
        )

    elif not signature_present:
        result = VerificationResult(
            'INVALID',
            'digital_signature_missing',
            'critical',
            'Embedded digital signature is missing.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            False
        )

    elif not signature_valid and payload_matches_trusted:
        result = VerificationResult(
            'INVALID',
            'digital_signature_altered',
            'critical',
            'The embedded digital signature was altered, but the metadata payload still matches the trusted record.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            False
        )

    elif not signature_valid and watermark_readable and not payload_matches_trusted:
        result = VerificationResult(
            'METADATA_ALTERED',
            'signed_metadata_modified',
            'high',
            'The embedded metadata payload was altered, which caused signature verification to fail.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            False
        )

    elif not signature_valid:
        result = VerificationResult(
            'INVALID',
            'invalid_signature',
            'critical',
            'Embedded signature is corrupted or unreadable.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            False
        )

    else:
        result = VerificationResult(
            'AUTHENTIC',
            'clean',
            'low',
            'Embedded signature is valid and both embedded and trusted hashes match the submitted content.',
            record.document_id,
            record.owner,
            record.mode,
            record.content_hash,
            embedded_hash,
            submitted_hash,
            True
        )

    db.add(
        VerificationLog(
            document_id=record.document_id,
            user_id=user_id,
            submitted_filename=upload.filename,
            result=result.result,
            tamper_type=result.tamper_type,
            severity=result.severity,
            details=result.details,
        )
    )
    db.commit()
    return result