from __future__ import annotations
from pathlib import Path
from typing import Dict, Tuple
import json
import zipfile
from xml.etree import ElementTree as ET
from docx import Document

CP_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/custom-properties'
VT_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'
FMTID = '{D5CDD505-2E9C-101B-9397-08002B2CF9AE}'
ET.register_namespace('', CP_NS)
ET.register_namespace('vt', VT_NS)


def extract_docx_text(path: Path) -> str:
    doc = Document(str(path))
    text = []
    for p in doc.paragraphs:
        text.append(p.text)
    for table in doc.tables:
        for row in table.rows:
            text.append(' | '.join(cell.text for cell in row.cells))
    return '\n'.join(text).strip()


def _make_custom_xml(payload: Dict, signature_b64: str) -> bytes:
    root = ET.Element(f'{{{CP_NS}}}Properties')
    props = {
        'MultiGuardDocumentId': payload['document_id'],
        'MultiGuardOwner': payload['owner'],
        'MultiGuardOrganization': payload.get('organization', ''),
        'MultiGuardIssuedAt': payload['issued_at'],
        'MultiGuardFileType': payload['file_type'],
        'MultiGuardContentHash': payload['content_hash'],
        'MultiGuardMode': payload['mode'],
        'MultiGuardPayloadJson': json.dumps(payload, ensure_ascii=False, separators=(',', ':')),
        'MultiGuardSignature': signature_b64,
    }
    pid = 2
    for name, value in props.items():
        prop = ET.SubElement(root, f'{{{CP_NS}}}property', {'pid': str(pid), 'fmtid': FMTID, 'name': name})
        lpwstr = ET.SubElement(prop, f'{{{VT_NS}}}lpwstr')
        lpwstr.text = str(value)
        pid += 1
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def _ensure_content_types(xml_bytes: bytes) -> bytes:
    tree = ET.fromstring(xml_bytes)
    ns = {'ct': 'http://schemas.openxmlformats.org/package/2006/content-types'}
    exists = any(el.attrib.get('PartName') == '/docProps/custom.xml' for el in tree.findall('ct:Override', ns))
    if not exists:
        ET.SubElement(tree, '{http://schemas.openxmlformats.org/package/2006/content-types}Override', {
            'PartName': '/docProps/custom.xml',
            'ContentType': 'application/vnd.openxmlformats-officedocument.custom-properties+xml'
        })
    return ET.tostring(tree, encoding='utf-8', xml_declaration=True)


def _ensure_rels(xml_bytes: bytes) -> bytes:
    tree = ET.fromstring(xml_bytes)
    ns = {'pr': 'http://schemas.openxmlformats.org/package/2006/relationships'}
    exists = any(el.attrib.get('Type') == 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties' for el in tree.findall('pr:Relationship', ns))
    if not exists:
        rid = 'rIdCustomProps'
        ET.SubElement(tree, '{http://schemas.openxmlformats.org/package/2006/relationships}Relationship', {
            'Id': rid,
            'Type': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties',
            'Target': 'docProps/custom.xml'
        })
    return ET.tostring(tree, encoding='utf-8', xml_declaration=True)


def embed_docx_watermark(source_path: Path, dest_path: Path, payload: Dict, signature_b64: str) -> None:
    custom_xml = _make_custom_xml(payload, signature_b64)
    with zipfile.ZipFile(source_path, 'r') as zin, zipfile.ZipFile(dest_path, 'w', zipfile.ZIP_DEFLATED) as zout:
        seen = set()
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == '[Content_Types].xml':
                data = _ensure_content_types(data)
            elif item.filename == '_rels/.rels':
                data = _ensure_rels(data)
            elif item.filename == 'docProps/custom.xml':
                data = custom_xml
            zout.writestr(item, data)
            seen.add(item.filename)
        if 'docProps/custom.xml' not in seen:
            zout.writestr('docProps/custom.xml', custom_xml)


def extract_docx_watermark(path: Path) -> Tuple[Dict | None, str | None]:
    if not zipfile.is_zipfile(path):
        return None, None
    with zipfile.ZipFile(path, 'r') as zf:
        if 'docProps/custom.xml' not in zf.namelist():
            return None, None
        root = ET.fromstring(zf.read('docProps/custom.xml'))
        values = {}
        for prop in root:
            name = prop.attrib.get('name')
            if len(prop):
                values[name] = prop[0].text or ''
        payload_json = values.get('MultiGuardPayloadJson')
        signature = values.get('MultiGuardSignature')
        payload = json.loads(payload_json) if payload_json else None
        return payload, signature
