from pathlib import Path
from typing import Dict, Tuple
import json
import pikepdf
from pypdf import PdfReader
from .crypto_service import WATERMARK_NS


def extract_pdf_text(pdf_path: Path) -> str:
    reader = PdfReader(str(pdf_path))
    parts = []
    for page in reader.pages:
        parts.append(page.extract_text() or '')
    return '\n'.join(parts).strip()


def embed_pdf_watermark(source_path: Path, dest_path: Path, payload: Dict, signature_b64: str) -> None:
    pdf = pikepdf.Pdf.open(source_path)
    with pdf.open_metadata(set_pikepdf_as_editor=False) as meta:
        meta.register_xml_namespace(WATERMARK_NS, 'multiguard')
        for k, v in payload.items():
            tag = 'multiguard:' + ''.join([k[0].lower() + k[1:]]) if k else k
            meta[tag] = json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)
        meta['multiguard:payloadJson'] = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        meta['multiguard:signature'] = signature_b64
    pdf.docinfo['/MultiGuardDocumentId'] = payload['document_id']
    pdf.docinfo['/MultiGuardContentHash'] = payload['content_hash']
    pdf.docinfo['/MultiGuardSignature'] = signature_b64
    pdf.save(dest_path)


def extract_pdf_watermark(pdf_path: Path) -> Tuple[Dict | None, str | None]:
    pdf = pikepdf.Pdf.open(pdf_path)
    payload = None
    signature = None
    with pdf.open_metadata(set_pikepdf_as_editor=False) as meta:
        if 'multiguard:payloadJson' in meta:
            try:
                payload = json.loads(str(meta['multiguard:payloadJson']))
            except Exception:
                payload = None
        if 'multiguard:signature' in meta:
            signature = str(meta['multiguard:signature'])
    if payload is None and '/MultiGuardContentHash' in pdf.docinfo:
        payload = {
            'document_id': str(pdf.docinfo.get('/MultiGuardDocumentId', '')),
            'content_hash': str(pdf.docinfo.get('/MultiGuardContentHash', '')),
        }
        signature = str(pdf.docinfo.get('/MultiGuardSignature', ''))
    return payload, signature
