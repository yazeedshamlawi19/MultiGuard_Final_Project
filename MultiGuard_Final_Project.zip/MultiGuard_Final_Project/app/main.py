from pathlib import Path
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session

from .auth import hash_password, verify_password
from .config import ALLOWED_EXTENSIONS, APP_NAME, SECRET_KEY, STATIC_DIR, TEMPLATES_DIR
from .database import Base, engine, get_db
from .models import User, DocumentRecord, VerificationLog
from .services.crypto_service import ensure_keys, PUBLIC_KEY_PATH
from .services.document_service import watermark_document, verify_document

app = FastAPI(title=APP_NAME, version='2.0.0')
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)
app.mount('/static', StaticFiles(directory=STATIC_DIR), name='static')
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

Base.metadata.create_all(bind=engine)
ensure_keys()


def seed_admin(db: Session):
    if not db.query(User).filter_by(email='admin@multiguard.local').first():
        db.add(
            User(
                email='admin@multiguard.local',
                password_hash=hash_password('Admin@1234'),
                full_name='MultiGuard Admin',
                organization='Research Lab',
                role='admin'
            )
        )
        db.commit()


with next(get_db()) as db:
    seed_admin(db)


def validate_extension(filename: str) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail='Only PDF, TXT, and DOCX files are supported.')
    return suffix


def current_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    uid = request.session.get('user_id')
    if not uid:
        return None
    return db.get(User, uid)


def require_user(user: User | None = Depends(current_user)) -> User:
    if user is None:
        raise HTTPException(status_code=401, detail='Login required')
    return user


@app.get('/', response_class=HTMLResponse)
def index(request: Request, db: Session = Depends(get_db), user: User | None = Depends(current_user)):
    if user is None:
        return templates.TemplateResponse(
            'auth.html',
            {
                'request': request,
                'app_name': APP_NAME
            }
        )

    # الملفات المسجلة للمستخدم
    docs = (
        db.query(DocumentRecord)
        .filter_by(user_id=user.id)
        .order_by(DocumentRecord.id.desc())
        .all()
    )

    # آخر 10 سجلات فقط للعرض
    logs = (
        db.query(VerificationLog)
        .filter_by(user_id=user.id)
        .order_by(VerificationLog.id.desc())
        .limit(10)
        .all()
    )

    # جميع السجلات للإحصائيات التراكمية
    all_logs = (
        db.query(VerificationLog)
        .filter_by(user_id=user.id)
        .all()
    )

    stats = {
        'documents': len(docs),
        'verified_authentic': sum(1 for l in all_logs if l.result == 'AUTHENTIC'),
        'tampered': sum(1 for l in all_logs if l.result == 'TAMPERED'),
        'invalid': sum(1 for l in all_logs if l.result == 'INVALID'),
        'metadata_altered': sum(1 for l in all_logs if l.result == 'METADATA_ALTERED'),
        'unregistered': sum(1 for l in all_logs if l.result == 'UNREGISTERED'),
        'total_verifications': len(all_logs),
    }

    return templates.TemplateResponse(
        'dashboard.html',
        {
            'request': request,
            'app_name': APP_NAME,
            'user': user,
            'docs': docs,
            'logs': logs,
            'stats': stats,
            'last_verification': request.session.get('last_verification'),
        }
    )


@app.post('/register')
def register(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    full_name: str = Form(...),
    organization: str = Form(''),
    db: Session = Depends(get_db)
):
    if db.query(User).filter_by(email=email).first():
        return templates.TemplateResponse(
            'auth.html',
            {
                'request': request,
                'app_name': APP_NAME,
                'error': 'Email already exists.'
            }
        )

    user = User(
        email=email,
        password_hash=hash_password(password),
        full_name=full_name,
        organization=organization
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    request.session['user_id'] = user.id
    return RedirectResponse('/', status_code=303)


@app.post('/login')
def login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter_by(email=email).first()
    if user is None or not verify_password(password, user.password_hash):
        return templates.TemplateResponse(
            'auth.html',
            {
                'request': request,
                'app_name': APP_NAME,
                'error': 'Invalid credentials.'
            }
        )

    request.session['user_id'] = user.id
    return RedirectResponse('/', status_code=303)


@app.get('/logout')
def logout(request: Request):
    request.session.clear()
    return RedirectResponse('/', status_code=303)


@app.post('/watermark')
def watermark(
    request: Request,
    file: UploadFile = File(...),
    owner: str = Form(...),
    organization: str = Form(''),
    description: str = Form(''),
    mode: str = Form('embedded'),
    db: Session = Depends(get_db),
    user: User = Depends(require_user)
):
    validate_extension(file.filename)
    record = watermark_document(db, file, user.id, owner, organization, description, mode)
    return RedirectResponse(f'/document/{record.document_id}', status_code=303)


@app.post('/verify')
def verify(
    request: Request,
    file: UploadFile = File(...),
    provided_document_id: str = Form(''),
    db: Session = Depends(get_db),
    user: User = Depends(require_user)
):
    validate_extension(file.filename)
    result = verify_document(db, file, user.id, provided_document_id or None)

    request.session['last_verification'] = {
        'result': result.result,
        'tamper_type': result.tamper_type,
        'severity': result.severity,
        'details': result.details,
        'document_id': result.document_id,
        'owner': result.owner,
        'mode': result.mode,
        'content_hash_db': result.content_hash_db,
        'content_hash_embedded': result.content_hash_embedded,
        'content_hash_submitted': result.content_hash_submitted,
        'signature_valid': result.signature_valid,
        'ui_status': 'success' if result.result == 'AUTHENTIC' else 'danger',
    }
    return RedirectResponse('/', status_code=303)


@app.get('/document/{document_id}', response_class=HTMLResponse)
def document_detail(
    document_id: str,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_user)
):
    record = db.query(DocumentRecord).filter_by(document_id=document_id, user_id=user.id).one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail='Not found')

    return templates.TemplateResponse(
        'document.html',
        {
            'request': request,
            'record': record,
            'user': user,
            'app_name': APP_NAME,
        }
    )


@app.get('/download/{document_id}')
def download(document_id: str, db: Session = Depends(get_db), user: User = Depends(require_user)):
    record = db.query(DocumentRecord).filter_by(document_id=document_id, user_id=user.id).one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail='Not found')
    path = Path(record.protected_path)
    return FileResponse(path, filename=path.name)


@app.get('/public-key')
def public_key(user: User = Depends(require_user)):
    return FileResponse(PUBLIC_KEY_PATH, filename='multiguard_public_key.pem')


@app.get('/api/documents')
def api_documents(db: Session = Depends(get_db), user: User = Depends(require_user)):
    docs = (
        db.query(DocumentRecord)
        .filter_by(user_id=user.id)
        .order_by(DocumentRecord.id.desc())
        .all()
    )
    return [
        {
            'document_id': d.document_id,
            'filename': d.original_filename,
            'file_type': d.file_type,
            'mode': d.mode,
            'hash': d.content_hash,
            'issued_at': d.issued_at.isoformat()
        }
        for d in docs
    ]