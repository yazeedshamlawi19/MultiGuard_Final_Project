Extract the project zip.
Open terminal inside the project folder.
Run:
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run.py